/*
Ryan Lebeau
04/11/2016
question3.c
*/

#include <stdio.h>
#include <math.h>
int main(void)
{
	/*3a will return the numbers:
	1 2 4 8 16 32 64 128*/
	
	/*3b will return the numbers:
	9384 938 93 9*/
	
	/*3c will return the numbers:
	5 4 3 2*/
}