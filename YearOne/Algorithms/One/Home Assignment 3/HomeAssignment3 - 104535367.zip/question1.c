/*
Ryan Lebeau
04/11/2016
question1.c
*/

#include<stdio.h>
int main(void)
{
	int age;
	bool teenage = false;
	if (age >= 13 && age <= 19){
		teenage = true;
	}
}