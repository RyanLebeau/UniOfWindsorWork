/*
Ryan Lebeau
04/11/2016
question4.c
*/

/*
4a

int n=1; a=1;
if (a>n && n>0){
	printf("Good!");
}
else{
	printf("Hello!");
}

Output: Hello!
*/

/*
4b

int k=1;
while (k<=10){
	printf("%d ", k);
	k += 1;
}

Output: 1 2 3 4 5 6 7 8 9 10
*/

/*
4c

int k=1;
do{
	printf("%d ", k);
	k += 1;
}while (k<=10);

Output: 1 2 3 4 5 6 7 8 9 10
*/

/*
4d

float x=10;
while (x>=1.001){
	printf("%d ", x);
	x = sqrt(x);
}

Output: 0 1073741824 536870912 -1610612736 -1073741824 0 1610612736 -2147483648 0 1610612736 -2147483648 -1610612736 
*/
















