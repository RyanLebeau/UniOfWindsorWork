//Question 1
/*
Move "double product;" inside the function
Put brackets around 'product / 2'

double triangle_area(double base, height)
{
	double product;
	product = base * height;
	return (product/2);
}
*/

//Question 2
/*
a is correct
*/

//Question 5
/*
This program could contain 2 different types of i, local and global.
Local variable should be used in main to avoid confusion if 
other functions are created.
*/