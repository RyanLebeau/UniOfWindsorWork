/*
Ryan Lebeau
19/11/2016
question3&4.c
*/

#include <stdio.h>
#include <stdbool.h>

int main(void)
{
	//question 3
	bool weekend_q3[7] = {true, false, false, false, false, false, true};
	
	//question 4
	bool weekend_q4[7] = {[0] = true, [6] = true};
}