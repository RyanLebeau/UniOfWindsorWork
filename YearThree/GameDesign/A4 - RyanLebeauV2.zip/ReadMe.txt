This submission 'A4 - RyanLebeauV2' has the sphere jumping altered such 
that consecutive jumps in a row can take place (similar to a double jump
system). My first submisison does not have this system. The line in the
assignment "The space bar should make the character jump in a one-off key 
press (as in, holding the space bar should not make your character constantly
 float but repetitive taps should keep the character  bouncing)." was ambiguous
so both versions were submitted.
