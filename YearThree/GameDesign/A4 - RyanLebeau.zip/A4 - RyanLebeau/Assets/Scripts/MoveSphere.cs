﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveSphere : MonoBehaviour {
    public Vector3 forward = new Vector3(0.0f, 0.0f, 0.1f);
    public Vector3 backward = new Vector3(0.0f, 0.0f, -0.1f);
    public Vector3 left = new Vector3(-0.1f, 0.0f, 0.0f);
    public Vector3 right = new Vector3(0.1f, 0.0f, 0.0f);
    public Vector3 jump = new Vector3(0.0f, 0.2f, 0.0f);
    public static Vector3 currentPos = new Vector3();
    public static float currentTime = 0;
    public static bool ifJump = false, ifCol = false;

    // Use this for initialization
    void Start () {
		
	}

    // Update is called once per frame
    void Update () {
        //Jump with SPACE only if you aren't currently jumping and if you are on an object
        if (Input.GetKeyDown(KeyCode.Space) && !ifJump && ifCol) {
            ifJump = true;
        }
    }

    // FixedUpdate is called once per 0.2s
    void FixedUpdate () {
        //Moving with WASD or arrow keys
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) {
            transform.Translate(forward);
        }
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) {
            transform.Translate(backward);
        }
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) {
            transform.Translate(left);
        }
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) {
            transform.Translate(right);
        }
        
        //if jump was triggered then move player for 0.5s
        if (ifJump) {
            if(currentTime <= 0.5) { 
                currentTime += Time.fixedDeltaTime;
                transform.Translate(jump);
            }
        }
        //get current position
        currentPos = transform.position;
    }
    
    void OnCollisionStay(Collision col) {
        //if player is jumping and lands
        if (ifJump) {
            currentTime = 0.0f;
            ifJump = false;
        }
        ifCol = true;
    }
    //if sphere is not on an object
    void OnCollisionExit(Collision col) {
        //ifCol = false;
    }

}
