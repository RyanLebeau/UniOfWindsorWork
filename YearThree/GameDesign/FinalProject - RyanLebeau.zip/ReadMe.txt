My FinalProject is titled 'PlatformMania', the scenes are properly 
layered in the build settings if it is being built. If it is only being
tested in the unity editor note that the 'Exit' buttons in the main
menu will not work since they utilize Application.Quit(). Also, I was
a little unsure with the requirements if the player can move off the
screen in the Y direction (since my camera does not follow the player
in the Y like a true side scroller), so similar to super mario it is allowed.

Thank you for a great semester with unity and a final project
that was very fun to create which most classes lack!
-Ryan Lebeau