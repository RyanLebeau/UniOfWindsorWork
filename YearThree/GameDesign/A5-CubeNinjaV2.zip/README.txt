intro scene = "StartCN"
player pref = "CubeNinjaScore"

there is a return to main menu button the function is 
in my 'EndCN' script file you have to put your main
menu scene name in it (line is commented out currently)

i have also sent the bg image like you said the hex code for 
the color i have the image(like the canvas object) is 5BBBC9FF