//Testing sequelize with the bungie api

class testSeq{
    private static apiKey: string = "fb4ec07747584b6b899e9f88200266b2";

    public static getAccountName(platform: string, username:string){
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "https://www.bungie.net/Platform/Destiny2/SearchDestinyPlayer/" + platform + "/" + username + "/", true);
        xhr.setRequestHeader("X-API-Key", testSeq.apiKey);
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var json = JSON.parse(this.responseText);
                if(json.Response[0] == undefined){
                    console.log("Player not found");
                    return false;
                }
                //apiFunction.platform = platform;
                //apiFunction.memId = json.Response[0].membershipId;
                //apiFunction.GetPlayerAccountInformation();
                //apiFunction.GetPlayerClanInformation();
            }
        }
    }
}
