/**
 * Sundance Destiny Stats
 * Bungie Net API Program
 */

//The API Key for our access to the Bungie Net API
export default class apiFunction {
    private static apiKey: string = "fb4ec07747584b6b899e9f88200266b2";
    private static memId: string;
    private static platform: string; 
    private static playerAccountInformation: any;
    private static currentCharacterInventory: any;
    private static databaseQueryValues: number[];
    private static PlayerClanData: any;
    /**
     * This function will accept the users platform and username as parameters, the bungie.net API is queried for their account.
     * A request is sent with our API Key in the headder of the request, and to a URL specific to this task.
     * This request will return a JSON file upon a sucessful query. The handling of this JSON file is handled in this function.
     * 
     * The function will return their Bungie Net 'MembershipID'  --MT
     * @param platform Integer that represents the users playform (-1 = any; 1 = Xbox; 2 = PlayStation; 4 = BattleNet)
     * @param username The users username for their respective platoform
     * @returns a string with the display name and membership Id
     */
    public static PlayerAccountSearch(platform: string, username: string) {

        //Setting up the XMLHttp Request to access the Bungie Net API; the URL here is unique to this task
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "https://www.bungie.net/Platform/Destiny2/SearchDestinyPlayer/" + platform + "/" + username + "/", true);
        xhr.setRequestHeader("X-API-Key", apiFunction.apiKey);
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var json = JSON.parse(this.responseText);
                if(json.Response[0] == undefined){
                    console.log("Player not found");
                    return false;
                }
                apiFunction.platform = platform;
                apiFunction.memId = json.Response[0].membershipId;
                apiFunction.GetPlayerAccountInformation();
                apiFunction.GetPlayerClanInformation();
            }
        }
        xhr.send();
    };

    /**
     * This function will take the users platform and membershipID as parameters. The bungie.net API is queried for their basic account information. 
     * A request is sent with our API Key in the headder of the request, and to a URL specific to this task.
     * This request will return a JSON file upon a sucessful query. The handling of this JSON file is handled in this function.
     * 
     * The function will return basic information about the users account.
     * @param platform Integer that represents the users playform (-1 = any; 1 = Xbox; 2 = PlayStation; 4 = BattleNet)
     * @param membershipID The users membership ID which is used to look up more information about their bungie.net account
     * @returns A string with some basic account information
     */
    public static GetPlayerAccountInformation() {

        var xhr = new XMLHttpRequest();
        xhr.open("GET", "https://www.bungie.net/Platform/Destiny2/" + apiFunction.platform + "/Profile/" + apiFunction.memId + "/?components=100", true);
        xhr.setRequestHeader("X-API-Key", apiFunction.apiKey);
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                apiFunction.playerAccountInformation = JSON.parse(this.responseText);
                console.log(apiFunction.playerAccountInformation);
                var characterString = apiFunction.playerAccountInformation.Response.profile.data.characterIds[2];
                apiFunction.GetCharacterInformation(characterString);
                apiFunction.GetCharacterInventory(characterString);
            }
        }
        xhr.send();
    }

    /**
     * This function will query the bungie.net API specifically for information on a particular player character
     * It takes a users platform, membership ID and character ID as input paramaters and will return information about that character
     * @param platform Integer that represents the users playform (-1 = any; 1 = Xbox; 2 = PlayStation; 4 = BattleNet)
     * @param membershipID The users membership ID which is used to look up more information about their bungie.net account
     * @param characterID The character ID for a particulat character that user has
     */
    public static GetCharacterInformation(characterID: string) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "https://www.bungie.net/Platform/Destiny2/" + apiFunction.platform + "/Profile/" + apiFunction.memId + "/Character/"+ characterID +"/?components=200", true);
        xhr.setRequestHeader("X-API-Key", apiFunction.apiKey);
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var json = JSON.parse(this.responseText);
                // console.log(json)
                return (json);
            }
        }
        xhr.send();
    }

     /**
     * This function will query the bungie.net API specifically for information on a particular player characters inventory
     * It takes a users platform, membership ID and character ID as input paramaters and will return information about that character
     * @param platform Integer that represents the users playform (-1 = any; 1 = Xbox; 2 = PlayStation; 4 = BattleNet)
     * @param membershipID The users membership ID which is used to look up more information about their bungie.net account
     * @param characterID The character ID for a particulat character that user has
     */
    public static GetCharacterInventory(characterID: string) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "https://www.bungie.net/Platform/Destiny2/" + apiFunction.platform + "/Profile/" + apiFunction.memId + "/Character/"+ characterID +"/?components=205", true);
        xhr.setRequestHeader("X-API-Key", apiFunction.apiKey);
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var json = JSON.parse(this.responseText);
                // console.log(json);
                apiFunction.currentCharacterInventory = json;
                // return (json);
            }
        }
        xhr.send();
    }

    /**
     * Function reads in unhashed values from character inventory and converts them to hased values that can be queried
     */
    public static LoadAndConvertInventory() {

        for (let i = 0; i < 9; i++) {
            this.databaseQueryValues[i] = apiFunction.currentCharacterInventory.Response.equipment.data.items[i].itemHash;
        }

        this.databaseQueryValues[9] = apiFunction.currentCharacterInventory.Response.equipment.data.items[11].itemHash;

        for (let i = 0; i < this.databaseQueryValues.length; i++) {
            this.databaseQueryValues[i] = this.ConvertDataHash(this.databaseQueryValues[i]);
        }
    }

    /**
     * This function will take an itemHash given to us by the API, and convert it to the appropriate value to be queried by the item database
     * @param val Val is the value of the itemHash given to us by the API
     * @returns the updated value of val that can now be queried within the database
     */
    public static ConvertDataHash(val:number) {

        if ((val & (1 << (32 - 1))) != 0) {
            val = val - 1 << 32;
            val++;
        }
        
        console.log(val);

        return val;
    
    }

    /**
     * This function will get clan data on the searched players clan and store that data in the class
     */
    public static GetPlayerClanInformation() {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "https://www.bungie.net/Platform/GroupV2/User/2/" + apiFunction.memId + "/0/1/", true);
        xhr.setRequestHeader("X-API-Key", apiFunction.apiKey);
        xhr.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var json = JSON.parse(this.responseText);
                apiFunction.PlayerClanData = json;
            }
        }
        xhr.send();
    }

}
