"use strict";
//import apiFunction from "./apiFunction";
//apiFunction.PlayerAccountSearch("4", "SolarPhantom%231257");