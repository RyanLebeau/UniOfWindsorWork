// import data from "./Assets/Database/DestinyInventoryItemDefinition.json";
import data from "C:/Users/dmd09/OneDrive/Documents/sundancedestinystats/src/Assets/Database/DestinyInventoryItemDefinition.json";

export default class find {

  static query() {
    console.log(data);
  }
}