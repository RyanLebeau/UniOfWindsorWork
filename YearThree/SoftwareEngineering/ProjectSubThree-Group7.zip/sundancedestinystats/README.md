# SundanceDestinyStats


Use this for Naming Conventions:
https://github.com/unional/typescript-guidelines/blob/master/pages/default/draft/naming-conventions.md

You wil need Node.js and npm, install them.  You will also need VScode and SourceTree.

Run these command after install the above.  npm init, then npm install

You need to compile before running, this is becuase the /dist folder is ignored(it is not needed in the repository, as it is only compiled code).

To start compile on save run "npm run tsc".

To run open the index.html in browser. // TODO: run with npm command

suck
my
cock
(Ryan test)
