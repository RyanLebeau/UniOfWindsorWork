(function(global){
    SystemJS.config({
        map: {
            app: 'dist/src'
        },
        packages:{
            app:{
                main: 'main.js',
                defaultExtension: 'js'
            }
        }
    });
})(this);